////////////////////////////////////////////////////////////////
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
//
//
//2012june11, creation for spisplitpatternplay
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
////////////////////////////////////////////////////////////////

#include <assert.h>
#include <vector>

#include <fstream>

#include <iostream>
#include <sstream>

#include "portaudio.h"
#include "wavset.h"
#include "midieventset.h"
#include "instrument.h"
using namespace std;

static std::string outstring;

Instrument::Instrument()
{
	instrumentname = "noinstname";
}

Instrument::~Instrument()
{
	vector<WavSet*>::iterator it;
	for(it=wavsetvector.begin(); it<wavsetvector.end(); it++)
	{
		if(*it!=NULL) 
		{
			delete *it;
		}
		else
		{
			assert(false);
		}
	}
}

bool Instrument::SetInstrumentName(string filenamepattern)
{
	instrumentname = filenamepattern;
	return true;
}

const char* Instrument::GetInstrumentName()
{
	return instrumentname.c_str();
}

const char* Instrument::GetInstrumentNameWithoutPath()
{
	outstring = instrumentname;
	int found = outstring.rfind('\\');
	if (found!=string::npos)
	{
		outstring = outstring.substr(found+1);
	}
	return outstring.c_str();
}

WavSet* Instrument::GetWavSetRandomly()
{
	WavSet* pWavSet = NULL;
	int random_integer;
	int lowest=1, highest=wavsetvector.size();
	int range=(highest-lowest)+1;
	random_integer = lowest+int(range*rand()/(RAND_MAX + 1.0));

	int idwavset = random_integer-1;
	pWavSet = wavsetvector.at(idwavset);
	return pWavSet;
}

WavSet* Instrument::GetWavSetFromMidiNoteNumber(int midinotenumber)
{
	WavSet* pWavSet = NULL;
	assert(midinotenumber>=0 && midinotenumber<128);
	int idwavset = wavsetvector.size()*midinotenumber/128;
	pWavSet = wavsetvector.at(idwavset);
	return pWavSet;
}

WavSet* Instrument::GetWavSetFromMidiNoteNumber(MidiEventSet* pMidiEventSet)
{
	assert(pMidiEventSet);
	WavSet* pWavSet = NULL;

	int notenumber = pMidiEventSet->GetNoteNumber();
	GetWavSetFromMidiNoteNumber(notenumber);
	return pWavSet;
}

class WavSet* Instrument::GetWavSetFromPatternCode(const char* patterncode, int patternrange)
{
	assert(patterncode);
	WavSet* pWavSet = NULL;
	int instrumentrange = wavsetvector.size();

	int patterncodenumber = atoi(patterncode);//todo: GetPatternCodeNumber(patterncode);
	if(patterncodenumber<0 || patterncodenumber>9) 
	{
		//todo:
		assert(false);
		return NULL;
	}
	int idwavset = instrumentrange*(patterncodenumber-1)/patternrange;
	pWavSet = wavsetvector.at(idwavset);
	return pWavSet;

}

bool Instrument::IsValidWavFolder(const char* wavfoldername)
{
	assert(wavfoldername);
	//todo, verify that wavfoldername contains wav files
	//      that wav files are valid
	return true;
}

const char* Instrument::GetWavFolderFromWavFoldersFilename(const char* wavfoldersfilename)
{
	assert(wavfoldersfilename);
	//1) load in all folders
	vector<string> foldernames;
	vector<string>::iterator it;
	ifstream ifs(wavfoldersfilename);
	string temp;
	while(getline(ifs,temp))
	{
		if(IsValidWavFolder(temp.c_str()))
		{
			foldernames.push_back(temp);
		}
	}
	if(foldernames.empty()) 
	{
		//can't find file of file is empty
		assert(false);
		return "";
	}

	//2) pick a folder at random
	int random_integer;
	int lowest=1, highest=foldernames.size();
	int range=(highest-lowest)+1;
	random_integer = lowest+int(range*rand()/(RAND_MAX + 1.0));


	outstring = foldernames.at(random_integer-1);
	return outstring.c_str();
}

bool Instrument::CreateFromWavFilenamesFile(const char* wavfilenamesfile, int maxnumberofwavset)
{
	//1) load in all wav files from wavfolder
	vector<string> wavfilenames;
	ifstream ifs(wavfilenamesfile); //ifstream ifs("wsic_filenames.txt");
	//ifstream ifs(wavfilenamesfile, ifstream::trunc); //ifstream ifs("wsic_filenames.txt");
	string temp;
	while(getline(ifs,temp))
	{
		wavfilenames.push_back(temp); //wavfilenames.push_back(path + "\\" + temp);
	}

	SetInstrumentName(wavfilenamesfile);//SetInstrumentName(wavfolder);
	//2) browse through these wav files, create and attach a wavset for each valid wav files
	vector<string>::iterator it;
	for(it=wavfilenames.begin(); it<wavfilenames.end(); it++)
	{
		//2.1) create wavset
		WavSet* pWavSet = new WavSet;
		pWavSet->ReadWavFile((*it).c_str()); //*it is a .wav filename
		//2.2) is supported?
		/*
		if(pWavSet->numChannels==1 && pWavSet->SampleRate==44100)
		{
			pWavSet->Resample44100monoTo44100stereo();
		}
		if( (pWavSet->numChannels==2 && pWavSet->SampleRate!=44100) 
			|| (pWavSet->numChannels==1 && pWavSet->SampleRate!=22050) )
		{
			printf("exluding %s because sample is %d Hz\n",(*it).c_str(),pWavSet->SampleRate);
			delete pWavSet;
			continue;
		}
		*/
		if(pWavSet->numChannels==1 && pWavSet->SampleRate==44100)
		{
			pWavSet->Resample44100monoTo44100stereo();
		}
		else if(pWavSet->numChannels==1 && pWavSet->SampleRate==48000)
		{
			pWavSet->Resample48000monoTo44100stereo();
		}
		else if(pWavSet->numChannels==2 && pWavSet->SampleRate==48000)
		{
			pWavSet->Resample48000stereoTo44100stereo();
		}
		if( (pWavSet->numChannels==2 && pWavSet->SampleRate!=44100) 
			|| (pWavSet->numChannels==1 && pWavSet->SampleRate!=22050) )
		{
			printf("exluding %s because sample is %d Hz\n",(*it).c_str(),pWavSet->SampleRate);
			delete pWavSet;
			continue;
		}
		//2.3) attach wavset
		if(wavsetvector.size()<= maxnumberofwavset)
		{
			wavsetvector.push_back(pWavSet);
		}
		else
		{
			break;
		}
	}
	if(wavsetvector.empty()) return false;
	return true;
}

bool Instrument::CreateFromWavFolder(const char* wavfolder, int maxnumberofwavset)
{
	assert(wavfolder);
	//0) execute cmd line to get all folder's .wav filenames
	string quote = "\"";
	string pathfilter;
	string path=wavfolder;
	pathfilter = path + "\\*.wav";
	string systemcommand;
	//systemcommand = "DIR " + quote + pathfilter + quote + "/B /O:N > wsic_filenames.txt"; //wsip tag standing for wav set (library) instrumentset (class) populate (function)
	systemcommand = "DIR " + quote + pathfilter + quote + "/B /S /O:N > wsic_filenames.txt"; // /S for adding path into "wsic_filenames.txt"
#ifdef _DEBUG
	cout << systemcommand << endl;
#endif //_DEBUG
	system(systemcommand.c_str());

	return CreateFromWavFilenamesFile("wsic_filenames.txt", maxnumberofwavset);
}

bool Instrument::CreateFromWavFilenamesFilter(const char* wavfilenamesfilter,  int maxnumberofwavset)
{
	//1) retreive all "wavfolder_*.txt" file
	//0) execute cmd line to get all folder's .wav filenames
	string quote = "\"";
	string pathfilter;
	//string path=wavfolder;
	//pathfilter = path + "\\*.wav";
	pathfilter = "wavfolder_*.txt";
	string systemcommand;
	systemcommand = "DIR " + quote + pathfilter + quote + "/B /O:N > wsic_txtfilenames.txt"; //wsip tag standing for wav set (library) instrumentset (class) populate (function)
#ifdef _DEBUG
	cout << systemcommand << endl;
#endif //_DEBUG
	system(systemcommand.c_str());

	//2) load in all "wavfolder_*.txt" file
	vector<string> txtfilenames;
	ifstream ifs("wsic_txtfilenames.txt");
	string temp;
	while(getline(ifs,temp))
	{
		//txtfilenames.push_back(path + "\\" + temp);
		txtfilenames.push_back(temp);
	}

	if(wavfilenamesfilter==NULL || strcmp(wavfilenamesfilter, "")==0)
	{
		//3.1) get a random wavfilenamesfile
		if(txtfilenames.empty()) 
		{
			//there is probably no "wavfolder_*.txt" in application directory
			//application directory is different depending if running debug or release version
			//typically, for developing debug and testing release, all "wavfolder_*.txt" files should be copied to both directory
			assert(false);
			return false;
		}
		//3.2) pick a folder at random
		int random_integer;
		int lowest=1, highest=txtfilenames.size();
		int range=(highest-lowest)+1;
		random_integer = lowest+int(range*rand()/(RAND_MAX + 1.0));

		outstring = txtfilenames.at(random_integer-1);
	}
	else
	{
		//4) use wavfilenamesfilter to get a wavfilenamesfile
		//assert(false); //todo
		//i.e. if pattern = "trombonesolo", it would specify a unique instrument
		//     if pattern = "trombone", it would find a few instrument and pick one at random
		string nopath = wavfilenamesfilter;
		int pos = nopath.rfind('\\');
		if(pos!=string::npos)
		{
			nopath = nopath.substr(pos+1,nopath.size());
		}
		//4.1) first, look for an exact match 
		vector<string>::iterator it;
		bool found = false;
		for(it=txtfilenames.begin(); it<txtfilenames.end(); it++)
		{
			if((*it).compare(nopath)==0) //if((*it).compare(wavfilenamesfilter)==0)
			{
				found=true;
				outstring = *it;
				break;
			}
		}
		if(found==false)
		{
			//4.2) second, look for substr matches
			vector<string> matchesvector;
			bool found = false;
			for(it=txtfilenames.begin(); it<txtfilenames.end(); it++)
			{
				if((*it).find(nopath)!=string::npos) //if((*it).compare(wavfilenamesfilter)==0)
				{
					found=true;
					matchesvector.push_back(*it);
				}
			}
			if(found==true)
			{
				//4.3) if a unique match is found
				if(matchesvector.size()==1)
				{
					outstring = matchesvector.at(0);
				}
				else
				{
					//4.4) if more than one match is found, pick one at random
					int random_integer;
					int lowest=1, highest=matchesvector.size();
					int range=(highest-lowest)+1;
					random_integer = lowest+int(range*rand()/(RAND_MAX + 1.0));

					outstring = matchesvector.at(random_integer-1);

				}
			}
			else
			{
				assert(false); //todo
				//1) find substr, build a vector of matching "wavfolder_*.txt" files
				//2) if more than one match found, pick one at random
				outstring = "wavfolder_basstuba.txt"; //for now, continue safely
			}
		}
	}
	return CreateFromWavFilenamesFile(outstring.c_str(), maxnumberofwavset);
}

bool Instrument::CreateFromWavFoldersFilename(const char* wavfoldersfilename, int maxnumberofwavset)
{
	assert(wavfoldersfilename);
	//1) pick a folder at random
	string wavfolder = GetWavFolderFromWavFoldersFilename(wavfoldersfilename);  

	//2) call CreateFromWavFolder()
	return CreateFromWavFolder(wavfolder.c_str(), maxnumberofwavset);
}

bool Instrument::CreateFromRootWavFoldersFilename(const char* rootwavfoldersfilename, int maxnumberofwavset)
{
	assert(rootwavfoldersfilename);
	//pick a folder at random
	string rootwavfolder = GetWavFolderFromWavFoldersFilename(rootwavfoldersfilename); //same function should work also for rootfolders

	//0) execute cmd line to get all root folder's sub folders
	string quote = "\"";
	string pathfilter;
	string path=rootwavfolder;
	pathfilter = path + "\\*."; //we want folders only
	string systemcommand;
	systemcommand = "DIR " + quote + pathfilter + quote + "/S /B /O:N > wavfolders_otherinstruments.txt"; // /S for recursive
#ifdef _DEBUG
	cout << systemcommand << endl;
#endif //_DEBUG
	system(systemcommand.c_str());

	return CreateFromWavFoldersFilename("wavfolders_otherinstruments.txt", maxnumberofwavset); 
}

bool Instrument::CreateFromName(const char* name, int maxnumberofwavset)
{
	assert(name);
	string namestring = name;
	if(namestring.compare("piano")==0)
	{
		return CreateFromWavFoldersFilename("wavfolders_piano.txt", maxnumberofwavset);
	}
	else if(namestring.compare("guitar")==0)
	{
		return CreateFromWavFoldersFilename("wavfolders_guitar.txt", maxnumberofwavset);
	}
	else if(namestring.compare("bass")==0)
	{
		return CreateFromWavFoldersFilename("wavfolders_bass.txt", maxnumberofwavset);
	}
	else if(namestring.compare("drumkit")==0)
	{
		return CreateFromWavFoldersFilename("wavfolders_drumkit.txt", maxnumberofwavset);
	}
	else if(namestring.compare("horns")==0)
	{
		return CreateFromWavFoldersFilename("wavfolders_horns.txt", maxnumberofwavset);
	}
	else if(namestring.compare("organ")==0)
	{
		return CreateFromWavFoldersFilename("wavfolders_organ.txt", maxnumberofwavset);
	}
	else if(namestring.compare("violin")==0)
	{
		return CreateFromWavFoldersFilename("wavfolders_violin.txt", maxnumberofwavset);
	}
	else if(namestring.compare("africa")==0)
	{
		return CreateFromWavFoldersFilename("wavfolders_otherinstruments_world_africa.txt", maxnumberofwavset);
	}
	else if(namestring.compare("otherinstruments")==0)
	{
		return CreateFromRootWavFoldersFilename("wavfolders_otherinstrumentsrootfolders.txt", maxnumberofwavset);
	}
	assert(false); //name must be in the list, otherwise use "otherinstruments"
	return false;
}

void Instrument::Play(PaStreamParameters* pPaStreamOutputParameters, int iflag)
{
	vector<WavSet*>::iterator it;
	if(iflag==INSTRUMENT_WAVSETINSEQUENCE)
	{
		for(it=wavsetvector.begin(); it<wavsetvector.end(); it++)
		{
			(*it)->Play(pPaStreamOutputParameters, INSTRUMENT_MAXWAVSETLENGTH);
		}
	}
	else if(iflag==INSTRUMENT_WAVSETALLATONCE)
	{
		//1) create audio buffer
		WavSet* pWavSet = new WavSet;
		if(pWavSet)
		{
			if(pWavSet->CreateSilence(INSTRUMENT_MAXWAVSETLENGTH))
			{
				string name = "";
				for(it=wavsetvector.begin(); it<wavsetvector.end(); it++)
				{
					name += (*it)->GetName();
					float amplitude = 0.25;
					int n = wavsetvector.size();
					if(n<11) amplitude=0.5;
					else if(n<21) amplitude=0.25;
					else if(n<51) amplitude=0.15;
					else amplitude = 0.1;
					pWavSet->Sum(amplitude, (*it), 0.0, INSTRUMENT_MAXWAVSETLENGTH);
				}
				//2) play it
				pWavSet->SetName(name.c_str());
				pWavSet->Play(pPaStreamOutputParameters);
				
			}
			//3) delete it
			delete pWavSet;
		}
	}
	else if(iflag==INSTRUMENT_WAVSETRANDOM)
	{
		//todo:
		assert(false);
	}
	else
	{
		assert(false);
	}
	return ;
}
