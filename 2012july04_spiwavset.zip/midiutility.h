#ifndef _MIDIUTILITY_H
#define _MIDIUTILITY_H

extern const char* notename[132];
extern const float notefreq[132];

int  GetMidiNoteNumberFromString(const char* pstring);
float GetFrequencyFromMidiNoteNumber(int midinotenumber);
int GetMidiNoteNumberFromFrequency(float frequency_hz);
#endif //_MIDIUTILITY_H