////////////////////////////////////////////////////////////////
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
//
//
//2012june01, creation with ReadWavFile(), SplitInSegments() and GetPointerToSegmentData() for spisplitshuffleplay
//2012june04, spi, added EraseSegment() for spisplitdisperseplay, tested OK
//2012june04, spi, added WriteWavFile() for spisplitdisperseplay
//2012june04, spi, added WavSet(WavSet* pWavSet) and Copy() for spisplitdisperseplay
//2012june04, spi, added WriteWavFile() for spisplitdisperseplay
//2012june06, spi, added FadeSegmentEdges() for spisplitdisperseplay
//2012june08, spi, added GetSegmentsLength() for spiplay
//2012june08, spi, added GetFileLength() for spiplay
//2012june10, spi, added ReadWavFileHeader() for spinavwavfolders_sspp 
//				in order to replace lib soundtouch by class wavset 
//				which will now depend on libsndfile
//2012june11, spi, added assert(numChannels==2); statements where ever needed
//				mono wav file not supported for now
//2012june11, spi, adding CreateSilence(), CreateSin() and CreateTri()
//				as well as Concatenate() and Mix()
//2012june12, spi, adding Copy(class WavSet* pWavSet, float duration_s, float offset_s)
//				and Copy(class WavSet* pWavSet, int duration_sample, int offset_sample)
//2012june12, spi, adding Play()
//
//
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
////////////////////////////////////////////////////////////////


#include <stdlib.h>
#include <stdio.h>
#include "portaudio.h"

/*
#include "WavFile.h"
#include "SoundTouch.h"
using namespace soundtouch;
*/
#include	<sndfile.hh>

#include "WavSet.h"
#include <memory.h>
#include <assert.h>
#include <math.h>
#define M_PI       3.14159265358979323846

WavSet::WavSet()
{
	Init();
}

void WavSet::Init()
{
	SampleRate = 0;
	totalFrames = 0; 
	numChannels = 0;
	numSamples = 0;  
	numBytes = 0;
	pSamples = NULL;

	numFramesPerSegment = -1;
	numSegments = -1;
	numSamplesPerSegment = -1;  
	numBytesPerSegment = -1;

	idSegmentSelected = -1;
}

WavSet::WavSet(WavSet* pWavSet, int idSegment)
{
	Copy(pWavSet,idSegment); //-1 for all segments
}

bool WavSet::Copy(WavSet* pWavSet, int idSegment) //-1 for all segments
{
	SampleRate = pWavSet->SampleRate;
	totalFrames = pWavSet->totalFrames; 
	numChannels = pWavSet->numChannels;
	numSamples = pWavSet->numSamples;  
	numBytes = pWavSet->numBytes;

	numFramesPerSegment = pWavSet->numFramesPerSegment;
	numSegments = pWavSet->numSegments;
	numSamplesPerSegment = pWavSet->numSamplesPerSegment;  
	numBytesPerSegment = pWavSet->numBytesPerSegment;

	idSegmentSelected = pWavSet->idSegmentSelected;

	if(numBytes!=0)
	{
		pSamples = (float*) malloc( numBytes );
		if( pSamples == NULL )
		{
			printf("Could not allocate load buffer.\n");
			exit(1);
		}
		if(idSegment==-1)
		{
			//copy all segments
			memcpy(pSamples, pWavSet->pSamples, numBytes);
		}
		else if(idSegment<numSegments)
		{
			//initialize buffer with zeros
			memset(pSamples, 0, numBytes);
			//copy one segment only
			float* pBaseFloatDest = GetPointerToSegmentData(idSegment);
			float* pBaseFloatSrc = pWavSet->GetPointerToSegmentData(idSegment);
			memcpy(pBaseFloatDest, pBaseFloatSrc, numBytesPerSegment);
		}
		else
		{
			printf("Could copy segment id %d\n", idSegment);
			if(pSamples) free(pSamples);
			exit(1);
		}
	}
	return true;
}

bool WavSet::Copy(WavSet* pWavSet, float duration_s, float offset_s)
{
	assert(pWavSet!=NULL && pSamples==NULL);
	int duration_frame=duration_s*pWavSet->SampleRate/(pWavSet->numChannels);
	int offset_frame=offset_s*pWavSet->SampleRate/(pWavSet->numChannels);
	return Copy(pWavSet, duration_frame, offset_frame);
}

bool WavSet::Copy(WavSet* pWavSet, int duration_frame, int offset_frame)
{
	assert(pWavSet!=NULL && pSamples==NULL);
	assert((duration_frame+offset_frame)<=pWavSet->totalFrames);

	SampleRate = pWavSet->SampleRate;
	totalFrames = duration_frame; 
	numChannels = pWavSet->numChannels;
	numSamples = totalFrames*numChannels;  
	numBytes = numSamples*sizeof(float);

	numFramesPerSegment = -1;
	numSegments = -1;
	numSamplesPerSegment = -1;  
	numBytesPerSegment = -1;

	idSegmentSelected = -1;

	if(numBytes!=0)
	{
		pSamples = (float*) malloc( numBytes );
		if( pSamples == NULL )
		{
			printf("error in wavset::copy(), could not allocate buffer.\n");
			exit(1);
		}
		memcpy(pSamples, &(pWavSet->pSamples[offset_frame*pWavSet->numChannels]), numBytes);
	}
	else
	{
		assert(false);
		return false;
	}
	return true;
}

WavSet::~WavSet()
{
	if(pSamples) free(pSamples);
}

bool WavSet::ReadWavFile(const char* filename)
{
	/////////////////////
	// open input file...
    /*
	WavInFile* pWavInFile = new WavInFile(filename);
	if(pWavInFile)
	*/
	SndfileHandle file;
	file = SndfileHandle(filename);
	if(1)
	{
		printf("Begin reading file.\n"); fflush(stdout);
		SampleRate = file.samplerate(); //pWavInFile->getSampleRate();
		totalFrames = file.frames(); //pWavInFile->getNumSamples(); 
		numChannels = file.channels(); //pWavInFile->getNumChannels();
		numSamples = totalFrames * numChannels;  
		numBytes = numSamples * sizeof(float);
		assert(pSamples==NULL);
		pSamples = (float*) malloc( numBytes );
		if( pSamples == NULL )
		{
			/////////////////////////////////////////////////////////////
			//log currently used parameters into file (to ease debugging)
			/////////////////////////////////////////////////////////////
			if(1)
			{
				FILE* pFILE = fopen("debug.txt", "a");
				fprintf(pFILE, "ReadWavFile():\n");
				fprintf(pFILE, "totalFrames = %d\n", totalFrames);
				fprintf(pFILE, "numChannels = %d\n", numChannels);
				fprintf(pFILE, "numSamples = %d\n", numSamples);
				fprintf(pFILE, "numBytes = %d\n", numBytes);
				fprintf(pFILE, "Could not allocate load buffer, exiting ...\n");
				fclose(pFILE);
			}
			printf("Could not allocate load buffer, exiting ...\n");
			exit(1);
		}
		//for(int i=0; i<numSamples; i++ ) pLoadedSamples[i] = 0;

		///////////////////////////////////////
		// read samples from the input file ...
		/*
		while (pWavInFile->eof() == 0)
		{
			// Read a chunk of samples from the input file
			int num = pWavInFile->read(pSamples, numSamples);
		}
		delete pWavInFile;
		*/
		file.read(pSamples, numSamples);

		printf("Done!\n"); fflush(stdout);
	}
	return true;
}

bool WavSet::WriteWavFile(const char* filename)
{
	/*
	WavOutFile* pWavOutFile = new WavOutFile(filename, SampleRate, 16, numChannels);
	if(pWavOutFile)
	{
		pWavOutFile->write(pSamples, totalFrames * numChannels);
		//pWavOutFile->close(); //close was provoquing a crash, file is automatically closed when WavOutFile object is deleted
		delete pWavOutFile;
	}
	return true;
	*/
    const int format=SF_FORMAT_WAV | SF_FORMAT_PCM_16;  
	//const int format=SF_FORMAT_WAV | SF_FORMAT_FLOAT;  
    //const int format=SF_FORMAT_WAV | SF_FORMAT_PCM_24;  
    //const int format=SF_FORMAT_WAV | SF_FORMAT_PCM_32;  
	SndfileHandle outfile(filename, SFM_WRITE, format, numChannels, SampleRate); 
	outfile.write(pSamples, numSamples);  
	return true;
}

bool WavSet::CreateSilence(float duration, int samplerate, int numchannel)
{
	assert(pSamples==NULL);
	if(pSamples!=NULL)
	{
		free(pSamples);
		Init();
	}
	SampleRate = samplerate; 
	totalFrames = SampleRate*duration; //duration is in seconds
	numChannels = numchannel; 
	numSamples = totalFrames * numChannels;  
	numBytes = numSamples * sizeof(float);
	assert(pSamples==NULL);
	pSamples = (float*) malloc( numBytes );
	memset(pSamples, 0, numBytes);
	return true;
}

bool WavSet::CreateSin(float duration, int samplerate, int numchannel)
{
	assert(pSamples==NULL);
	if(pSamples!=NULL)
	{
		free(pSamples);
		Init();
	}
	SampleRate = samplerate; 
	totalFrames = SampleRate*duration; //duration is in seconds
	numChannels = numchannel; 
	numSamples = totalFrames * numChannels;  
	numBytes = numSamples * sizeof(float);
	assert(pSamples==NULL);
	pSamples = (float*) malloc( numBytes );
	//todo:
	if(numChannels==1)
	{
		for (int i=0; i<numSamples; i++) pSamples[i]=sin(float(i)/numSamples*M_PI*1500); //higher freq 
		//for (int i=0; i<size; i++) sample[i]=sin(float(i)/size*M_PI*750);  //lower freq
	}
	else if (numChannels==2)
	{
		for (int i=0; i<numSamples; i=i+2) 
		{
			pSamples[i]=sin(float(i)/numSamples*M_PI*1500); //higher freq 
			pSamples[i+1]=sin(float(i+1)/numSamples*M_PI*1500); //higher freq 
		}
	}
	else
	{
		assert(false);
		return false;
	}
	return true;
}

bool WavSet::CreateTri(float duration, int samplerate, int numchannel)
{
	assert(pSamples==NULL);
	if(pSamples!=NULL)
	{
		free(pSamples);
		Init();
	}
	SampleRate = samplerate; 
	totalFrames = SampleRate*duration; //duration is in seconds
	numChannels = numchannel; 
	numSamples = totalFrames * numChannels;  
	numBytes = numSamples * sizeof(float);
	assert(pSamples==NULL);
	pSamples = (float*) malloc( numBytes );
	//todo:
	assert(false);
	memset(pSamples, 0, numBytes);
	//todo:
	return true;
}

bool WavSet::Concatenate(class WavSet* pWavSet)
{
	if(pWavSet==NULL || pWavSet->pSamples==NULL) 
	{
		printf("error in wavset::concatenate\n");
		assert(false);
		return false;
	}
	if(pSamples!=NULL)
	{
		assert(numChannels==pWavSet->numChannels);
		assert(SampleRate==pWavSet->SampleRate);
		pSamples = (float* )realloc(pSamples, numBytes+pWavSet->numBytes);
		memcpy(&(pSamples[numSamples]), pWavSet->pSamples, pWavSet->numBytes);
		totalFrames=totalFrames+pWavSet->totalFrames;
		numSamples=numSamples+pWavSet->numSamples;
		numBytes=numBytes+pWavSet->numBytes;
	}
	else
	{
		Copy(pWavSet);
	}
	return true;
}

bool WavSet::Mix(float amplitude1, WavSet* pWavSet1, float amplitude2, WavSet* pWavSet2)
{
	if(pWavSet1==NULL || pWavSet1->pSamples==NULL || pWavSet1->numBytes==0) 
	{
		printf("error in wavset::mix, pWavSet1==NULL || pWavSet1->pSamples==NULL\n");
		assert(false);
		return false;
	}
	if(pWavSet2==NULL || pWavSet2->pSamples==NULL || pWavSet2->numBytes==0) 
	{
		printf("error in wavset::mix, pWavSet2==NULL || pWavSet2->pSamples==NULL\n");
		assert(false);
		return false;
	}
	if(pSamples!=NULL)
	{
		printf("error in wavset::mix, attempting to mix into previously allocated buffer\n");
		assert(false);
		return false;
	}
	assert(pWavSet1->numChannels==pWavSet2->numChannels);
	assert(pWavSet1->SampleRate==pWavSet2->SampleRate);
	SampleRate=pWavSet1->SampleRate;
	numChannels=pWavSet1->numChannels;
	int numsamplesdifference=0;
	if(pWavSet1->numBytes>=pWavSet2->numBytes)
	{
		totalFrames=pWavSet1->totalFrames;
		numSamples=pWavSet1->numSamples;
		numBytes=pWavSet1->numBytes;
		numsamplesdifference=pWavSet1->numSamples-pWavSet2->numSamples;
	}
	else
	{
		totalFrames=pWavSet2->totalFrames;
		numSamples=pWavSet2->numSamples;
		numBytes=pWavSet2->numBytes;
		numsamplesdifference=pWavSet2->numSamples-pWavSet1->numSamples;
	}
	pSamples = (float*)malloc(numBytes);if(pSamples==NULL) {printf("error in wavset::mix, not enough memory.\n");return false;}
	if(numChannels==1)
	{
		for (int i=0; i<(numSamples-numsamplesdifference); i++) 
		{
			pSamples[i]=amplitude1*pWavSet1->pSamples[i]+amplitude2*pWavSet2->pSamples[i];  
		}
	}
	else if (numChannels==2)
	{
		for (int i=0; i<(numSamples-numsamplesdifference); i=i+2) 
		{
			pSamples[i]=amplitude1*pWavSet1->pSamples[i]+amplitude2*pWavSet2->pSamples[i];  
			pSamples[i+1]=amplitude1*pWavSet1->pSamples[i+1]+amplitude2*pWavSet2->pSamples[i];  
		}
	}
	else
	{
		assert(false);
		return false;
	}
	if(pWavSet1->numBytes>pWavSet2->numBytes)
	{
		if(numChannels==1)
		{
			for (int i=(numSamples-numsamplesdifference); i<numSamples; i++) 
			{
				pSamples[i]=amplitude1*pWavSet1->pSamples[i];  
			}
		}
		else if (numChannels==2)
		{
			for (int i=(numSamples-numsamplesdifference); i<numSamples; i=i+2) 
			{
				pSamples[i]=amplitude1*pWavSet1->pSamples[i];  
				pSamples[i+1]=amplitude1*pWavSet1->pSamples[i+1];  
			}
		}
	}
	else
	{
		if(numChannels==1)
		{
			for (int i=(numSamples-numsamplesdifference); i<numSamples; i++) 
			{
				pSamples[i]=amplitude2*pWavSet2->pSamples[i];  
			}
		}
		else if (numChannels==2)
		{
			for (int i=(numSamples-numsamplesdifference); i<numSamples; i=i+2) 
			{
				pSamples[i]=amplitude2*pWavSet2->pSamples[i];  
				pSamples[i+1]=amplitude2*pWavSet2->pSamples[i+1];  
			}
		}
	}
	return true;
}

bool WavSet::SplitInSegments(double fSecondsPerSegment)
{
	numFramesPerSegment = fSecondsPerSegment * SampleRate;
	if(numFramesPerSegment>totalFrames || fSecondsPerSegment==0.0) 
	{
		/////////////////////////////////////////////////////////////
		//log currently used parameters into file (to ease debugging)
		/////////////////////////////////////////////////////////////
		if(1)
		{
			FILE* pFILE = fopen("debug.txt", "a");
			fprintf(pFILE, "SplitInSegments():\n");
			fprintf(pFILE, "fSecondsPerSegment = %f\n", fSecondsPerSegment);
			fprintf(pFILE, "SampleRate = %d\n", SampleRate);
			fprintf(pFILE, "numFramesPerSegment = %d\n", numFramesPerSegment);
			fprintf(pFILE, "totalFrames = %d\n", totalFrames);
			fprintf(pFILE, "(numFramesPerSegment>totalFrames || fSecondsPerSegment==0.0)==1, warning ...\n");
			fclose(pFILE);
		}
		printf("(numFramesPerSegment>totalFrames || fSecondsPerSegment==0.0)==1, warning ...\n");
		//return false;
		//assert(false);
		numFramesPerSegment=totalFrames;
	}
	numSegments = totalFrames/numFramesPerSegment;
	numSamplesPerSegment = numFramesPerSegment * numChannels;  
	numBytesPerSegment = numSamplesPerSegment * sizeof(float);
	return true;
}

float* WavSet::GetPointerToSegmentData(int idSegment)
{
	if(pSamples==NULL || idSegment>(numSegments-1)) 
	{
		assert(false);
		return NULL; //error
	}
	return pSamples+idSegment*numSamplesPerSegment;
}

bool WavSet::EraseSegment(int idSegment)
{
	assert(numChannels==2);
	for(int i=0; i<numFramesPerSegment; i++ )
    {
        *(GetPointerToSegmentData(idSegment)+2*i) = 0;  /* left */
        *(GetPointerToSegmentData(idSegment)+2*i+1) = 0;  /* right */
    }
    return 0;

	return true;
}

bool WavSet::FadeSegmentEdges(int idSegment)
{
	//numFramesPerEdge is half of the total number of frames to fade
	//int numFramesPerEdge = numFramesPerSegment/4; //pretty much the largest value
	//int numFramesPerEdge = 100; //pretty much the smallest value
	int numFramesPerEdge = numFramesPerSegment/16; 

	//if(numFramesPerSegment<(2*100)) 
	if(numFramesPerSegment<(2*numFramesPerEdge)) 
	{
		/////////////////////////////////////////////////////////////
		//log currently used parameters into file (to ease debugging)
		/////////////////////////////////////////////////////////////
		if(1)
		{
			FILE* pFILE = fopen("debug.txt", "a");
			fprintf(pFILE, "FadeSegmentEdges():\n");
			fprintf(pFILE, "idSegment = %d\n", idSegment);
			fprintf(pFILE, "numFramesPerSegment = %d\n", numFramesPerSegment);
			fprintf(pFILE, "numFramesPerEdge = %d\n", numFramesPerEdge);
			fprintf(pFILE, "Not enough frames for FadeSegmentEdges().\n");
			fclose(pFILE);
		}
		printf("Not enough frames for FadeSegmentEdges().\n");
		return false;
	}
	float a,aa;
	int ii;
	assert(numChannels==2);
	//for(int i=0; i<100; i++ )
	for(int i=0; i<numFramesPerEdge; i++ )
    {
		//starting edge
		//a = i/100.0f;
		a = i/(1.0f*numFramesPerEdge); //a has values between 0.0 and 1.0, fade in factor
        *(GetPointerToSegmentData(idSegment)+2*i) = a*(*(GetPointerToSegmentData(idSegment)+2*i));  /* left */
        *(GetPointerToSegmentData(idSegment)+2*i+1) = a*(*(GetPointerToSegmentData(idSegment)+2*i+1));  /* right */

		//ending edge
		aa = 1-a; //aa has values between 1.0 and 0.0, fade out factor
		//ii = numFramesPerSegment-100+i;
		ii = numFramesPerSegment-numFramesPerEdge+i;
        *(GetPointerToSegmentData(idSegment)+2*ii) = aa*(*(GetPointerToSegmentData(idSegment)+2*ii));  /* left */
        *(GetPointerToSegmentData(idSegment)+2*ii+1) = aa*(*(GetPointerToSegmentData(idSegment)+2*ii+1));  /* right */
    }
	return true;
}

float WavSet::GetSegmentsLength()
{
	return (numFramesPerSegment*numSegments/(1.0*SampleRate));
}

float WavSet::GetFileLength()
{
	return (totalFrames/(1.0*SampleRate));
}

//2012june10, spi, added ReadWavFileHeader() for spinavwavfolders_sspp 
//				in order to replace lib soundtouch by class wavset 
//				which will now depend on libsndfile
bool WavSet::ReadWavFileHeader(const char* filename)
{
	assert(pSamples==NULL);
	assert(numBytes==0);
	SndfileHandle file;
	file = SndfileHandle(filename);
	if(1)
	{
		SampleRate = file.samplerate(); //pWavInFile->getSampleRate();
		totalFrames = file.frames(); //pWavInFile->getNumSamples(); 
		numChannels = file.channels(); //pWavInFile->getNumChannels();
		numSamples = totalFrames * numChannels;  
		//do not allocate in here, use ReadWavFile() to allocate and read the whole file
		numBytes = 0; //numSamples * sizeof(float);
		
	}
	return true;
}

bool WavSet::Play(PaStreamParameters* pPaStreamOutputParameters)
{
	assert(pPaStreamOutputParameters!=NULL);
    PaStream* pPaStream=NULL;
    PaError err;
	/////////////////////////////////////
	// play wavset as is using port audio 
	/////////////////////////////////////
	printf("Begin playback.\n"); fflush(stdout);
	err = Pa_OpenStream(
				&pPaStream, //&stream
				NULL, // no input
				pPaStreamOutputParameters, //&outputParameters,
				SampleRate, //pWavSet->SampleRate,
				WAVSET_PLAY_BUFFERSIZE/numChannels, //pWavSet->numChannels,
				paClipOff,      // we won't output out of range samples so don't bother clipping them 
				NULL, // no callback, use blocking API 
				NULL ); // no callback, so no callback userData 
	if( err != paNoError ) goto error;

	if(pPaStream) //if(stream)
	{
		err = Pa_StartStream(pPaStream); //stream
		if( err != paNoError ) goto error;
		printf("Waiting for playback to finish.\n"); fflush(stdout);

		err = Pa_WriteStream(pPaStream, pSamples, totalFrames); //stream, pWavSet->pSamples, pWavSet->totalFrames
		if( err != paNoError ) goto error;

		err = Pa_CloseStream(pPaStream); //stream
		if( err != paNoError ) goto error;
		printf("Done.\n"); fflush(stdout);
	}

	return true;
error:
    Pa_Terminate();
    fprintf( stderr, "wavset::play(), an error occured while using the portaudio stream\n" );
    fprintf( stderr, "Error number: %d\n", err );
    fprintf( stderr, "Error message: %s\n", Pa_GetErrorText( err ) );
    return false;
}
