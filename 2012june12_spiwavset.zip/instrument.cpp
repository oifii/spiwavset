////////////////////////////////////////////////////////////////
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
//
//
//2012june11, creation for spisplitpatternplay
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
////////////////////////////////////////////////////////////////

#include <assert.h>
#include <vector>
#include "portaudio.h"
#include "wavset.h"
#include "instrument.h"
using namespace std;

Instrument::Instrument()
{
}
Instrument::~Instrument()
{
	vector<WavSet*>::iterator it;
	for(it=wavsetvector.begin(); it<wavsetvector.end(); it++)
	{
		if(*it!=NULL) 
		{
			delete *it;
		}
		else
		{
			assert(false);
		}
	}
}

