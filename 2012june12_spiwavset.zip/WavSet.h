////////////////////////////////////////////////////////////////
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
//
//
//2012june01, creation with ReadWavFile(), SplitInSegments() and GetPointerToSegmentData() for spisplitshuffleplay
//2012june04, spi, added EraseSegment() for spisplitdisperseplay, tested OK
//2012june04, spi, added WriteWavFile() for spisplitdisperseplay
//2012june04, spi, added WavSet(WavSet* pWavSet) and Copy() for spisplitdisperseplay
//2012june04, spi, added WriteWavFile() for spisplitdisperseplay
//2012june06, spi, added FadeSegmentEdges() for spisplitdisperseplay
//2012june08, spi, added GetSegmentsLength() for spiplay
//2012june08, spi, added GetFileLength() for spiplay
//2012june10, spi, added ReadWavFileHeader() for spinavwavfolders_sspp 
//				in order to replace lib soundtouch by class wavset 
//				which will now depend on libsndfile
//2012june11, spi, added assert(numChannels==2); statements where ever needed
//				mono wav file not supported for now
//2012june11, spi, adding CreateSilence(), CreateSin() and CreateTri()
//				as well as Concatenate() and Mix()
//2012june12, spi, adding Copy(class WavSet* pWavSet, float duration_s, float offset_s)
//				and Copy(class WavSet* pWavSet, int duration_sample, int offset_sample)
//2012june12, spi, adding Play()
//
//
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
////////////////////////////////////////////////////////////////
#define _WAVSET_H

#define WAVSET_PLAY_BUFFERSIZE 2048

class WavSet
{
public:
	int SampleRate;
	int totalFrames; 
	int numChannels;
	int numSamples;  
	int numBytes;
	float* pSamples;

	int numFramesPerSegment;
	int numSegments;
	int numSamplesPerSegment;  
	int numBytesPerSegment;

	int idSegmentSelected;

	WavSet();
	void Init();
	WavSet(class WavSet* pWavSet, int idSegment=-1);
	bool Copy(class WavSet* pWavSet, int idSegment=-1);
	bool Copy(class WavSet* pWavSet, float duration_s, float offset_s);
	bool Copy(class WavSet* pWavSet, int duration_frame, int offset_frame);
	~WavSet();
	bool ReadWavFile(const char* filename);
	bool WriteWavFile(const char* filename);
	bool SplitInSegments(double fSecondsPerSegment);
	float* GetPointerToSegmentData(int idSegment);
	bool EraseSegment(int idSegment);
	bool FadeSegmentEdges(int idSegment);
	float GetSegmentsLength();
	float GetFileLength();
	bool ReadWavFileHeader(const char* filename);
	bool CreateSilence(float duration, int samplerate=44100, int numchannel=2);
	bool CreateSin(float duration, int samplerate=44100, int numchannel=2);
	bool CreateTri(float duration, int samplerate=44100, int numchannel=2);
	bool Concatenate(class WavSet* pWavSet);
	bool Mix(float amplitude1, class WavSet* pWavSet1, float amplitude2, class WavSet* pWavSet2);
	bool Play(struct PaStreamParameters* pPaStreamOutputParameters);
};