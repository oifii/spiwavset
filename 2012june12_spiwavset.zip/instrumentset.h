////////////////////////////////////////////////////////////////
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
//
//
//2012june11, creation for spisplitpatternplay
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
////////////////////////////////////////////////////////////////
#define _INSTRUMENTSET_H

class InstrumentSet
{
public:
	std::vector<class Instrument*> instrumentvector;
	InstrumentSet();
	~InstrumentSet();
	void Populate(const char* wavfilesfolder);
	void Populate(std::vector<string>* wavfilenames);
	bool IsNewFilenamePattern(const char* prevfilename, const char* newfilename);
};