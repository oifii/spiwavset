////////////////////////////////////////////////////////////////
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
//
//
//2012june11, creation for spisplitpatternplay
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
////////////////////////////////////////////////////////////////
#define _INSTRUMENT_H

#include <vector>

class Instrument
{
public:
	std::vector<class WavSet*> wavsetvector;
	std::string instrumentname;
	Instrument();
	~Instrument();
	bool SetInstrumentName(std::string filenamepattern);
	const char* GetInstrumentName();
	class WavSet* GetWavSetRandomly();
	class WavSet* GetWavSetFromMidiNoteNumber(class MidiEventSet* pMidiEventSet);
};