////////////////////////////////////////////////////////////////
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
//
//
//2012june11, creation for spisplitpatternplay
//nakedsoftware.org, spi@oifii.org or stephane.poirier@oifii.org
////////////////////////////////////////////////////////////////

#include <assert.h>
#include <vector>
#include "portaudio.h"
#include "wavset.h"
#include "midieventset.h"
#include "instrument.h"
using namespace std;

Instrument::Instrument()
{
	instrumentname = "noinstname";
}

Instrument::~Instrument()
{
	vector<WavSet*>::iterator it;
	for(it=wavsetvector.begin(); it<wavsetvector.end(); it++)
	{
		if(*it!=NULL) 
		{
			delete *it;
		}
		else
		{
			assert(false);
		}
	}
}

bool Instrument::SetInstrumentName(string filenamepattern)
{
	instrumentname = filenamepattern;
	return true;
}

const char* Instrument::GetInstrumentName()
{
	return instrumentname.c_str();
}

WavSet* Instrument::GetWavSetRandomly()
{
	WavSet* pWavSet = NULL;
	int random_integer;
	int lowest=1, highest=wavsetvector.size();
	int range=(highest-lowest)+1;
	random_integer = lowest+int(range*rand()/(RAND_MAX + 1.0));

	int idwavset = random_integer-1;
	pWavSet = wavsetvector.at(idwavset);
	return pWavSet;
}

WavSet* Instrument::GetWavSetFromMidiNoteNumber(MidiEventSet* pMidiEventSet)
{
	assert(pMidiEventSet);
	WavSet* pWavSet = NULL;

	int notenumber = pMidiEventSet->GetNoteNumber();
	int idwavset = wavsetvector.size()*notenumber/128;
	pWavSet = wavsetvector.at(idwavset);
	return pWavSet;
}

